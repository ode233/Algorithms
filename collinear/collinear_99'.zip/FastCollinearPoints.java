/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.MergeX;


public class FastCollinearPoints {
    private int num = 0;
    private LineSegment[] lsMid;
    // public Point[] points;

    public FastCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException("points is null");
        }
        int numOfpoint = points.length;
        int len = numOfpoint;
        int maxLen = (len - 3) * (len + 2) / 6;
        if (len < maxLen) len = maxLen;
        for (int i = 0; i < numOfpoint; i++) {
            if (points[i] == null) throw new IllegalArgumentException("point is null");
            for (int j = i + 1; j < numOfpoint; j++) {
                if (points[i].equals(points[j]))
                    throw new IllegalArgumentException("point is duplicate");
            }
        }
        // this.points = points;
        lsMid = new LineSegment[len];
        Point[] pointOrder = new Point[numOfpoint];
        for (int i = 0; i < numOfpoint; i++) {
            pointOrder[i] = points[i];
        }
        MergeX.sort(pointOrder);
        double[] slops = new double[len];
        Point[] lastPoints = new Point[len];
        for (int i = 0; i < numOfpoint - 3; i++) {
            Point[] pointTemp = new Point[numOfpoint - i - 1
                    ];
            for (int j = i + 1; j < numOfpoint; j++) {
                pointTemp[j - i - 1] = pointOrder[j];
            }
            MergeX.sort(pointTemp, pointOrder[i].slopeOrder());
            int lenOfTemp = pointTemp.length;
            for (int k = 0; k < lenOfTemp - 2; k++) {
                double slope = pointOrder[i].slopeTo(pointTemp[k]);
                if (pointOrder[i].slopeTo(pointTemp[k + 2]) == slope) {
                    k = k + 2;
                    while (k < lenOfTemp - 1
                            && pointOrder[i].slopeTo(pointTemp[k + 1]) == slope)
                        k++;
                    boolean token = true;
                    for (int z = 0; z < num; z++) {
                        if (slops[z] == slope
                                && pointTemp[k].equals(lastPoints[z])) {
                            token = false;
                            break;
                        }
                    }
                    if (token) {
                        lastPoints[num] = pointTemp[k];
                        slops[num] = slope;
                        lsMid[num] = new LineSegment(pointOrder[i], pointTemp[k]);
                        num++;
                    }
                }
            }
        }
    }

    public int numberOfSegments() {
        return num;
    }

    public LineSegment[] segments() {
        LineSegment[] ls = new LineSegment[num];
        for (int i = 0; i < num; i++) {
            ls[i] = lsMid[i];
        }
        return ls;
    }

/*    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        StdDraw.setScale(0, 32767);
        StdDraw.setPenRadius(0.005);
        int n = Integer.parseInt(StdIn.readString());
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            points[i] = new Point(Integer.parseInt(StdIn.readString()),
                                  Integer.parseInt(StdIn.readString()));
            points[i].draw();
        }
        FastCollinearPoints cp = new FastCollinearPoints(points);
        for (int i = 0; i < cp.numberOfSegments(); i++) {
            cp.segments()[i].draw();
        }
        System.out.println(cp.numberOfSegments());
        long endTime = System.currentTimeMillis();
        double excTime = (double) (endTime - startTime) / 1000;
        System.out.println("执行时间：" + excTime + "s");
    }*/

    public static void main(String[] args) {

    }

}
