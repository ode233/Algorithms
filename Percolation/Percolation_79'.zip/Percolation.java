/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private WeightedQuickUnionUF pe;
    private boolean[] pb;
    private int num = 0;
    private int limit;

    public Percolation(int n) {
        validate(n);
        pe = new WeightedQuickUnionUF(n * n);
        limit = n;
        for (int i = 1; i < n; i++) pe.union(0, i);
        pb = new boolean[n * n];
        for (int i = 0; i < n * n; i++) pb[i] = false;
    }


    private void validate(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("index " + n + " should > 0 ");
        }
    }

    public void open(int row, int col) {
        validate(row, col);
        int idx = (row - 1) * limit + col - 1;
        if (!isOpen(row, col)) {
            pb[idx] = true;
            num++;
        }
        if (row - 1 > 0 && isOpen(row - 1, col))
            pe.union(idx, idx - limit);
        if (row + 1 <= limit && isOpen(row + 1, col))
            pe.union(idx, idx + limit);
        if (col - 1 > 0 && isOpen(row, col - 1))
            pe.union(idx, idx - 1);
        if (col + 1 <= limit && isOpen(row, col + 1))
            pe.union(idx, idx + 1);
    }

    public boolean isOpen(int row, int col) {
        validate(row, col);
        return pb[(row - 1) * limit + col - 1];
    }

    public int numberOfOpenSites() {
        return num;
    }

    public boolean isFull(int row, int col) {
        validate(row, col);
        boolean k = pe.find((row - 1) * limit + col - 1) == pe.find(0) && isOpen(row, col);
        return k;
    }

    public boolean percolates() {
        boolean x = false;
        for (int i = 1; i <= limit && !x; i++)
            x = isFull(limit, i);
        return x;
    }

    private void validate(int row, int col) {
        if (row < 1 || row > limit || col < 1 || col > limit) {
            throw new IllegalArgumentException("row or col  should between 1 and " + limit);
        }
    }

    public static void main(String[] args) {
        Percolation pl = new Percolation(3);
        pl.open(1, 1);
        pl.open(2, 1);
        pl.open(3, 1);
        // pe.open(3, 3);
        pl.open(3, 2);
        System.out.println(pl.isFull(3, 2));
    }
}
