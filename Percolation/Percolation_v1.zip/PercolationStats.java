/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private double[] p;

    public PercolationStats(int n, int trials) {
        p = new double[trials];
        for (int i = 0; i < trials; i++) {
            Percolation per = new Percolation(n);
            int j = 0;
            int t = 0;
            for (; !per.percolates(); j++) {
                int row = StdRandom.uniform(n) + 1;
                int col = StdRandom.uniform(n) + 1;
                if (!per.isOpen(row, col)) {
                    per.open(row, col);
                    t++;
                }
            }
            p[i] = (double) t / (double) (n * n);
        }
    }

    public double mean() {
        double pb = StdStats.mean(p);
        return pb;
    }

    public double stddev() {
        double std = StdStats.stddev(p);
        return std;
    }

    public double confidenceLo() {
        double lo = mean() - 1.96 * stddev() / Math.sqrt(p.length);
        return lo;
    }

    public double confidenceHi() {
        double hi = mean() + 1.96 * stddev() / Math.sqrt(p.length);
        return hi;
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats ps = new PercolationStats(n, t);
        System.out.println("mean = " + ps.mean());
        System.out.println("stddv = " + ps.stddev());
        System.out.println(
                "95% confidence interval = [ " + ps.confidenceLo() + ", " + ps.confidenceHi()
                        + " ]");
        // PercolationStats ps = new PercolationStats(10, 10);
        // double k = ps.mean();
        // System.out.println(1);
    }
}
