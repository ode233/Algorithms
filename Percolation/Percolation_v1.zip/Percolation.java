/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

public class Percolation {
    private int[][] id;
    private int[][] sz;
    private int[][] pb;
    private int num = 0;
    private int limit;

    public Percolation(int n) {
        validate(n);
        limit = n;
        id = new int[n][n];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (i == 1) id[i - 1][j - 1] = 1;
                else id[i - 1][j - 1] = (i - 1) * limit + j;
            }
        }
        sz = new int[n][n];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                sz[i - 1][j - 1] = 1;
            }
        }
        pb = new int[n][n];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                pb[i - 1][j - 1] = 0;
            }
        }
    }

    private void validate(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("index " + n + " should > 0 ");
        }
    }

    public int[] find(int row, int col) {
        validate(row, col);
        while ((row - 1) * limit + col != id[row - 1][col - 1]) {
            int k = id[row - 1][col - 1];
            if (k % limit == 0) {
                row = k / limit;
                col = limit;
            }
            else {
                row = k / limit + 1;
                col = k % limit;
            }
        }
        int[] a = { row, col };
        return a;
    }

    public void open(int row, int col) {
        validate(row, col);
        if (pb[row - 1][col - 1] == 0) {
            pb[row - 1][col - 1] = 1;
            num++;
        }
        if (row - 1 > 0 && isOpen(row - 1, col)) {
            int[] i = find(row, col);
            int[] j = find(row - 1, col);
            if (i == j) return;
            if (sz[i[0] - 1][i[1] - 1] < sz[j[0] - 1][j[1] - 1]) {
                id[i[0] - 1][i[1] - 1] = (j[0] - 1) * limit + j[1];
                sz[j[0] - 1][j[1] - 1] += sz[i[0] - 1][i[1] - 1];
            }
            else {
                id[j[0] - 1][j[1] - 1] = (i[0] - 1) * limit + i[1];
                sz[i[0] - 1][i[1] - 1] += sz[j[0] - 1][j[1] - 1];
            }
        }
        if (row + 1 <= limit && isOpen(row + 1, col)) {
            int[] i = find(row, col);
            int[] j = find(row + 1, col);
            if (i == j) return;
            if (sz[i[0] - 1][i[1] - 1] < sz[j[0] - 1][j[1] - 1]) {
                id[i[0] - 1][i[1] - 1] = (j[0] - 1) * limit + j[1];
                sz[j[0] - 1][j[1] - 1] += sz[i[0] - 1][i[1] - 1];
            }
            else {
                id[j[0] - 1][j[1] - 1] = (i[0] - 1) * limit + i[1];
                sz[i[0] - 1][i[1] - 1] += sz[j[0] - 1][j[1] - 1];
            }
        }
        if (col - 1 > 0 && isOpen(row, col - 1)) {
            int[] i = find(row, col);
            int[] j = find(row, col - 1);
            if (i == j) return;
            if (sz[i[0] - 1][i[1] - 1] < sz[j[0] - 1][j[1] - 1]) {
                id[i[0] - 1][i[1] - 1] = (j[0] - 1) * limit + j[1];
                sz[j[0] - 1][j[1] - 1] += sz[i[0] - 1][i[1] - 1];
            }
            else {
                id[j[0] - 1][j[1] - 1] = (i[0] - 1) * limit + i[1];
                sz[i[0] - 1][i[1] - 1] += sz[j[0] - 1][j[1] - 1];
            }
        }
        if (col + 1 <= limit && isOpen(row, col + 1)) {
            int[] i = find(row, col);
            int[] j = find(row, col + 1);
            if (i == j) return;
            if (sz[i[0] - 1][i[1] - 1] < sz[j[0] - 1][j[1] - 1]) {
                id[i[0] - 1][i[1] - 1] = (j[0] - 1) * limit + j[1];
                sz[j[0] - 1][j[1] - 1] += sz[i[0] - 1][i[1] - 1];
            }
            else {
                id[j[0] - 1][j[1] - 1] = (i[0] - 1) * limit + i[1];
                sz[i[0] - 1][i[1] - 1] += sz[j[0] - 1][j[1] - 1];
            }
        }
    }

    public boolean isOpen(int row, int col) {
        validate(row, col);
        return pb[row - 1][col - 1] == 1;
    }

    public int numberOfOpenSites() {
        return num;
    }

    public boolean isFull(int row, int col) {
        validate(row, col);
        int[] a = find(row, col);
        int[] b = find(1, 1);
        return (a[0] == b[0] && a[1] == b[1] && pb[row - 1][col - 1] == 1);
    }

    public boolean percolates() {
        boolean x = false;
        for (int i = 1; i <= limit && !x; i++)
            x = isFull(limit, i);
        return x;
    }

    private void validate(int row, int col) {
        if (row < 1 || row > limit || col < 1 || col > limit) {
            throw new IllegalArgumentException("row or col  is not between 0 and " + limit);
        }
    }

    public static void main(String[] args) {
        Percolation pe = new Percolation(3);
        pe.open(1, 1);
        pe.open(2, 1);
        pe.open(3, 1);
        // pe.open(3, 3);
        pe.open(3, 2);
        int[] a = pe.find(3, 2);
        System.out.println(pe.id[1][1]);
        System.out.println(pe.id[2][1]);
        System.out.println(a[0]);
        System.out.println(a[1]);
        System.out.println(pe.isFull(3, 2));
    }
}
