/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;

public class WordNet {
    private final ArrayList<String> synsets = new ArrayList<String>();
    private final SET<String> set = new SET<String>();
    private final SAP sap;
    private int size;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) {
            throw new IllegalArgumentException("arg is null");
        }
        In sv = new In(synsets);
        while (!sv.isEmpty()) {
            this.synsets.add(sv.readLine().split(",")[1]);
        }
        for (String s : this.synsets) {
            String[] lineOfSynsets = s.split(" ");
            for (String w : lineOfSynsets) {
                set.add(w);
            }
        }
        In hy = new In(hypernyms);
        size = this.synsets.size();
        Digraph digraph = new Digraph(size);
        while (!hy.isEmpty()) {
            String[] line = hy.readLine().split(",");
            int v = Integer.parseInt(line[0]);
            for (int i = 1; i < line.length; i++) {
                digraph.addEdge(v, Integer.parseInt(line[i]));
            }
        }
        int root = 0;
        for (int i = 0; i < size; i++) {
            if (digraph.outdegree(i) == 0) {
                root++;
            }
        }
        if (root != 1) {
            throw new IllegalArgumentException("not a rooted DAG");
        }
        sap = new SAP(digraph);
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return set;
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        return set.contains(word);
    }

    public int distance(String nounA, String nounB) {
        if (nounA == null || nounB == null) {
            throw new IllegalArgumentException("noun is null");
        }
        if (!isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException("noun is not in wordnet");
        }
        ArrayList<Integer> indexA = new ArrayList<Integer>();
        for (int i = 0; i < size; i++) {
            String[] lineOfSynsets = synsets.get(i).split(" ");
            for (String w : lineOfSynsets) {
                if (nounA.equals(w)) {
                    indexA.add(i);
                }
            }
        }
        ArrayList<Integer> indexB = new ArrayList<Integer>();
        for (int i = 0; i < size; i++) {
            String[] lineOfSynsets = synsets.get(i).split(" ");
            for (String w : lineOfSynsets) {
                if (nounB.equals(w)) {
                    indexB.add(i);
                }
            }
        }
        return sap.length(indexA, indexB);
    }

    public String sap(String nounA, String nounB) {
        if (nounA == null || nounB == null) {
            throw new IllegalArgumentException("noun is null");
        }
        if (!isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException("noun is not in wordnet");
        }
        ArrayList<Integer> indexA = new ArrayList<Integer>();
        for (int i = 0; i < size; i++) {
            String[] lineOfSynsets = synsets.get(i).split(" ");
            for (String w : lineOfSynsets) {
                if (nounA.equals(w)) {
                    indexA.add(i);
                }
            }
        }
        ArrayList<Integer> indexB = new ArrayList<Integer>();
        for (int i = 0; i < size; i++) {
            String[] lineOfSynsets = synsets.get(i).split(" ");
            for (String w : lineOfSynsets) {
                if (nounB.equals(w)) {
                    indexB.add(i);
                }
            }
        }
        int indexOfSap = sap.ancestor(indexA, indexB);
        return synsets.get(indexOfSap);
    }


    // do unit testing of this class
    public static void main(String[] args) {
        WordNet wd = new WordNet("synsets.txt", "hypernyms.txt");
        while (!StdIn.isEmpty()) {
            String nounA = StdIn.readString();
            String nounB = StdIn.readString();
            StdOut.println(wd.isNoun(nounA));
            StdOut.println(wd.sap(nounA, nounB));
            StdOut.println(wd.distance(nounA, nounB));
        }
    }
}
