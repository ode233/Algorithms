/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    private SearchNode delSN;


    public Solver(Board initial) {
        if (initial == null) throw new IllegalArgumentException("initial can not be null");
        int move = 0;
        delSN = new SearchNode(initial, null, move);
        MinPQ<SearchNode> minPQ = new MinPQ<SearchNode>();
        minPQ.insert(delSN);
        SearchNode delSNT;
        int moveT = 0;
        delSNT = new SearchNode(initial.twin(), null, moveT);
        MinPQ<SearchNode> minPQT = new MinPQ<SearchNode>();
        minPQT.insert(delSNT);
        while (!delSNT.board.isGoal() && !delSN.board.isGoal()) {
            delSN = minPQ.delMin();
            move = delSN.move + 1;
            for (Board bd : delSN.board.neighbors()) {
                if (delSN.previous == null || !bd.equals(delSN.previous.board))
                    minPQ.insert(new SearchNode(bd, delSN, move));
            }
            delSNT = minPQT.delMin();
            moveT = delSNT.move + 1;
            for (Board bd : delSNT.board.neighbors()) {
                if (delSNT.previous == null || !bd.equals(delSN.previous.board))
                    minPQT.insert(new SearchNode(bd, delSNT, moveT));
            }
        }
    }

    private class SearchNode implements Comparable<SearchNode> {
        private final Board board;
        private final int move;
        private final int manhattan;
        private final SearchNode previous;

        private SearchNode(Board board, SearchNode previous, int move) {
            manhattan = board.manhattan() + move;
            this.board = board;
            this.previous = previous;
            this.move = move;

        }

        @Override
        public int compareTo(SearchNode that) {
            return Integer.compare(this.manhattan, that.manhattan);
        }
    }


    public boolean isSolvable() {
        return delSN.board.isGoal();
    }

    public int moves() {
        if (!isSolvable()) return -1;
        return delSN.move;
    }

    public Iterable<Board> solution() {
        if (!isSolvable()) return null;
        Stack<Board> track = new Stack<Board>();
        SearchNode trackNode = delSN;
        while (trackNode != null) {
            track.push(trackNode.board);
            trackNode = trackNode.previous;
        }
        return (track);
    }


    public static void main(String[] args) {

        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
